package com.example.deliverymapping;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DeliverymappingApplicationTests {

	@Test
	void contextLoads() {
	}

}
