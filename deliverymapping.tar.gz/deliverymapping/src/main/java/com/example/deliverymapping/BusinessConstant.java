package com.example.deliverymapping;

public class BusinessConstant {
    public static enum PROCESS_STATUS {
        PENDING, COMPLETED, INFEASIBLE, UNABLETOPROCESS 
    }

    public static enum ROUTE_PROCESS_STATUS {
        PENDING, NOTCOMPLETED, COMPLETED
    }
}
